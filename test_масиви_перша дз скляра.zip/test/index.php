<h1>TEST</h1>

<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

echo 'How are you?<br>';
echo "\n";
echo 'I\'m fine.';

$gam_t = 'Gamburger';
$gam = 4.95;
$milk_t = 'Milk koktail';
$milk = 1.95;
$kk_t = 'Coca_cola';
$kk = 0.85;
$tax_t = 'Taxes';
$tax = 0.075;
$tea_t = 'Chaevue';
$tea = 0.16;



?>


<table>
    <tr>
        <th><?php echo $gam_t ?></th>
        <th><?php echo $milk_t ?></th>
        <th><?php echo $kk_t ?></th>
        <th><?php echo $tax_t ?></th>
        <th><?php echo $tea_t ?></th>
    </tr>
    <tr>
        <th><?php echo $gam ?></th>
        <th><?php echo $milk ?></th>
        <th><?php echo $kk ?></th>
        <th><?php echo $tax ?></th>
        <th><?php echo $tea ?></th>
    </tr>

</table>
<?php echo 'Order amount - '. ((2*$gam)+$milk+$kk)*(1+$tax)*(1+$tea) .'  !<br>'?>


<?php

$arr = array(
        "0",
        "2",
        "3",
        "4"
);

  print_r($arr);
  var_dump($arr);
  echo '<br>';
  ?>
<table>
    <tr>
        <?php
  foreach ($arr as $arrey)
  {
     echo '<th>'.$arrey.'</th>';
  }
?>
 </tr>

</table>


<?php
$arr1 = array(
["0","1"],
["2","3"],
["4","5"],
["6","7"],
);

echo "<pre>";
print_r($arr1);
echo "</pre>";
?>


<table>
    <tr>
 <?php
foreach ($arr1 as $arrey1)
{
    foreach ($arrey1 as $arrey2)
    {
        echo '<th>'.$arrey2.'</th>';
    }
?>
    </tr><tr>
        <?php
}
 ?>
    </tr>

</table>


<form action="" method="post">
    <div>
        <label for="login">Login</label>
        <input type="text" name="login" id="login">
    </div>
    <div>
        <label for="password">Password</label>
        <input type="password" name="password" id="password">
    </div>
    <div>
        <input type="submit" value="Sign in" name="submit">
    </div>
</form>

<h1>Signup</h1>
<form action="" method="post">
    <div>
        <label for="login">Login</label>
        <input type="text" name="login" id="login">
    </div>
    <div>
        <label for="password">Password</label>
        <input type="password" name="password" id="password">
    </div>
    <div>
        <input type="submit" value="Sign up" name="submit">
    </div>
</form>


<?php

function __construct()
    {
        $this->con = $this->connect();
    }

function actionSignup()
    {
        if(isset($_POST['submit']))
        {
            $this->signup();
        }

        //$model = new User();
        //print_r($model->findByLogin('123'));
        //return $this->render('auth/signup');

        //return $this->render('auth/signup');
    }

function connect()
    {
            $pdo = new PDO('mysql:dbname=localhost; host=localhost', root, root);
            $pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
            $pdo->exec("SET CHARACTER SET utf8");
            return $pdo;
    }
    

function signup($data)
{
$db = $this->con;
$sql = 'INSERT INTO '.$this->tableName().' SET
login = :login,
password = :password,
status = :status,
created_at = :created_at,
updated_at = :updated_at,
last_visit = :last_visit';

$guestRole = UserHelper::GUEST_ROLE;
$statusActive = UserHelper::STATUS_ACTIVE;
$currentTimestamp = DateHelper::currentTimestamp();
$login = Html::filter($data['login']);
$password = Security::passwordHash($data['password']);

$stmt = $db->prepare($sql);
$stmt->bindParam(':login', $login);
$stmt->bindParam(':password', $password);
$stmt->bindParam(':status', $statusActive);
//$stmt->bindParam(':role', $guestRole);
$stmt->bindParam(':created_at', $currentTimestamp);
$stmt->bindParam(':updated_at', $currentTimestamp);
$stmt->bindParam(':last_visit', $currentTimestamp);
$stmt->execute();
return true;
}


?>



