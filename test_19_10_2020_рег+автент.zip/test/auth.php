<h1>Auth</h1>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home task</title>
</head>
<body>
<form action="auth" method="POST">
    <label for="login1" >Login</label>
    <input type="text" name="login1" id="login1">
    <br>
    <label for="password" >Password</label>
    <input type="password" name="password1" id="password1">
    <br>
    <input type="submit" id="button" value="Enter">
</form>

</body>
</html>
<?php

$db = 'localhost';
$log = 'root';
$pas = 'root';


echo $_POST['login1'];
//$db = Db::connect();
$pdo = new PDO("mysql:host=localhost;dbname=".$db.";",$log,$pas);
$pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
$pdo->exec("SET CHARACTER SET utf8");

$sql_l = 'SELECT * FROM test_user WHERE login = :login';
$stmt = $pdo->prepare($sql_l);
$stmt->bindParam(':login', $_POST['login1']);
$stmt->execute();
return $stmt->fetch();

echo $_POST['login1'];

echo $stmt;
print_r($stmt);

$sql_id = 'SELECT * FROM test_user WHERE id = :id';
$stmt_id = $pdo->prepare($sql_id);
$stmt_id->bindParam(':id',$id);
$stmt_id->execute();
return $stmt_id->fetch();

//echo $sql_id;