<?php
//ob_start(); //Start buffering
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home task</title>
</head>
<h1>Registration</h1>
<body>
<form action="login" method="POST">
    <label for="login" >Login</label>
    <input type="text" name="login" id="login">
    <br>
    <label for="password" >Password</label>
    <input type="password" name="password" id="password">
    <br>
    <input type="submit" id="button" value="Enter">
</form>

</body>
</html>

<?php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

echo $_POST['login'];
echo '<br>';
echo $_POST['password'];
echo '<br>';
print_r($_POST);


$db = 'localhost';
$log = 'root';
$pas = 'root';

//public $pdo;
$pdo = new PDO("mysql:host=localhost;dbname=".$db.";",$log,$pas);
$pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
$pdo->exec("SET CHARACTER SET utf8");


echo '<br>';


if (isset($pdo))
{
    echo 'true';
}

//insert();
//function insert(){
$sql = 'INSERT INTO test_user SET
         login = :login,
         password = :password';


$stmt = $pdo->prepare($sql);
$stmt->bindParam(':login', $_POST['login']);
$stmt->bindParam(':password', password_hash($_POST['password'], PASSWORD_DEFAULT));
$stmt->execute();
//return true;
//}
echo '<script>location.replace(\'http://test/auth.php\')</script>';
exit;
//header(" Location: http://test/auth.php");
//exit;

/*
if($_POST = true){
    header(" Location: test/auth.php");
}


if(insert() == true)
{
    echo '<script>location.replace(test/auth.php)';
    header('Location: test/auth.php');
    exit;
}
*/


?>
