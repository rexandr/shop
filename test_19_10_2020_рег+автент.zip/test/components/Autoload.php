<?php
namespace components;

class Autoload
{
    private $folders =
        [
            'controllers',
            'models'
        ];
}