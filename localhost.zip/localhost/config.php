<?php
define('DATE_FORMAT', 'Y-m-d H:i:s');
define('UPLOAD_JPG', '/uploads/image/jpg/');
define('UPLOAD_PNG', '/uploads/image/png/');
define('UPLOAD_OTHERS', '/uploads/image/others/');
?>