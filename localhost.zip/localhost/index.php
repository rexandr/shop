<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
define('ROOT',__DIR__);
include ROOT.'/config.php';

function uploadFile($file){
print_r($file);
    if ($file['file']['size'] > 5000000) {
          echo '<h2>To big file</h2>';
        return false;
      }
    if (strstr($file['file']['name'], '.jpg')) {
        $fileRote = ROOT.UPLOAD_JPG.basename($file['file']['name']);
        }
        if (strstr($file['file']['name'], '.png')) {
            $fileRote = ROOT . UPLOAD_PNG . basename($file['file']['name']);
        }
            else{
                $fileRote = ROOT . UPLOAD_OTHERS . basename($file['file']['name']);
            }
        if (copy($file['file']['tmp_name'], $fileRote)) {
            return true;
        }
        else{
            return false;
        }
}
if(isset($_POST['zag'])) {
    if (uploadFile($_FILES)) {
        echo '<h2>Success</h2>';
    } else {
        echo '<h2>Unsuccess</h2>';
    }
}
?>

<form action="" enctype="multipart/form-data" method="post">
    <h2>Upload file</h2>
    <input type="file" name="file">
    <input type="submit" value="Send" name="zag">
</form>