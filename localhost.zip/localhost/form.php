<?php
/*echo $_GET['login'];
echo $_GET['radio'];
foreach ($_GET['checkbox'] as $checkbox){
    echo $checkbox.'<br>';
}*/

foreach ($_GET['color'] as $color){
    echo $color.'<br>';
}


foreach ($_GET['brand'] as $brand){
    echo $brand.'<br>';
}
?>