<?php
namespace controllers;

use models\SigninForm;
use models\SignupForm;
use components\Controller;
//use models\User;
use components\User;

class  AuthController extends Controller
{
    public function actionSignup()
    {
        if(isset($_POST['submit']))
        {
            $model = new SignupForm($_POST);
            $model->signup();
        }

        //$model = new User();
        //print_r($model->findByLogin('123'));
        //return $this->render('auth/signup');

        return $this->render('auth/signup');
    }


    public function actionSignin()
    {
        $errors = [];
        if(isset($_POST['submit']))
        {
            $model = new SigninForm($_POST);
            if (!$model->signin())
            {
                $errors = $model->errors;
            }
            else
            {
                User::auth($model->signin());
            }
        }
        return$this->render('auth/signin', ['errors' => $errors]);
    }
}