<?php

namespace controllers;

use components\Controller;

class ErrorController extends Controller
{
    public function actionError($message, $status)
    {
        header("HTTP/1.0 404 Not Found");
        return $this->render('error/error', [
            'message' => $message,
            'status' => $status,
        ]);
    }
}
?>