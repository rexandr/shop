<?php
return[
    '/'=>'site/index',
    '/contact' => 'site/contact',
    '/auth/signup' => 'auth/signup',
    '/auth/signin' => 'auth/signin',
    '/auth/logout' => 'auth/logout'
];

?>