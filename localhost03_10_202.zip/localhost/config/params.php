<?php
//Db params
defined('DB_SERVER') or define('DB_SERVER', 'localhost');
defined('DB_USER') or define('DB_USER', 'root');
defined('DB_PASSWORD') or define('DB_PASSWORD', 'root');
defined('DB_NAME') or define('DB_NAME', 'localhost');
//Assets params
defined('ASSET_PATH') or define('ASSET_PATH', '/public/');
defined('CSS_VERSION') or define('CSS_VERSION', null);
defined('JS_VERSION') or define('JS_VERSION', null);

?>
