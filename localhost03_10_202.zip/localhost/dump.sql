create  table  `user`(
  `id` int(11) AUTO_INCREMENT,
  `login` varchar (255) default null,
  `password` varchar (255) default  null,
  `status` int(1) default null,
  `role` int(1) default  null,
  `created_at` int(11) default  null,
  `updated_at` int(11) default null,
  `last_visit` int(11) default null,
  primary key(`id`)
);