<h1>Signup</h1>
<form action="" method="post">
    <div>
    <label for="login">Login</label>
    <input type="text" name="login" id="login">
    </div>
    <div>
        <label for="password">Password</label>
        <input type="password" name="password" id="password">
    </div>
    <div>
        <input type="submit" value="Signup" name="submit">
    </div>
</form>