<?php
use helpers\FormHelper;
?>
<h1>Sign in</h1>
<?php
echo FormHelper::errors($errors);
?>
<form action="" method="post">
    <div>
        <label for="login">Login</label>
        <input type="text" name="login" id="login">
    </div>
    <div>
        <label for="password">Password</label>
        <input type="password" name="password" id="password">
    </div>
    <div>
        <input type="submit" value="Sign in" name="submit">
    </div>
</form>