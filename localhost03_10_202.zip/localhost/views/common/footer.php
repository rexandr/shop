<?php
use assets\AppAssets;
$assets = new AppAssets();
echo $assets->initJs();



?>
</body>
</html>