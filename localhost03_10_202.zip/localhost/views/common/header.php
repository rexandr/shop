<?php
use assets\AppAssets;
use components\User;
$assets = new AppAssets;

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
        echo $assets->initCss();
    ?>
</head>
<body>
<nav>
    <ul>
        <li><a href="/">Home</a></li>
        <li><a href="/contact">Contact</a></li>
        <?php if (User::isAuth()): ?>
            <?php $info = User::info(); ?>
            <li><p>Hello: <?php echo $info['login'];?> </p>
                <a href="/auth/logout">logout</a>
            </li>

        <?php else: ?>
        <li><a href="/auth/signin">Sign in</a></li>
        <li><a href="/auth/signup">Sign up</a></li>
        <?php endif; ?>
    </ul>

</nav>

