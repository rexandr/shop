<?php
namespace components;

use PDO;
use PDOException;
use components\Logs;

class Db
{
    public static function connect()
    {

        try {
            $pdo = new PDO('mysql:dbname='.DB_NAME.';host='.DB_SERVER, DB_USER, DB_PASSWORD);
            $pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
            $pdo->exec("SET CHARACTER SET utf8");
            return $pdo;
        }
        catch (PDOException $e){
            Logs::add('Error Database connect', $e->getMessage());
            die($e->getMessage());
        }
    }
}