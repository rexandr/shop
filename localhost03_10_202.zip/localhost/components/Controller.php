<?php

namespace components;

class Controller
{
    private const VIEW_PATH = 'views';

    public function render($file, $data = [])
    {
        if (count($data)>0)
        {
            foreach ($data as $key=>$value){
                ${$key} =$value;
            }
        }
        if($this->isTemplateExist('common/header')) {
            include ROOT . '/' . self::VIEW_PATH . '/common/header.php';
        }
        if($this->isTemplateExist($file)) {
            include ROOT . '/' . self::VIEW_PATH . '/' . $file . '.php';
        }
        if($this->isTemplateExist('common/footer')) {
            include ROOT . '/' . self::VIEW_PATH . '/common/footer.php';
        }
        return true;
    }

    public function isTemplateExist($file)
    {
        if(!file_exists(ROOT.'/'.self::VIEW_PATH.'/'.$file.'.php'))
        {
            $filePath = ROOT.'/'.self::VIEW_PATH.'/'.$file.'.php';
            Logs::add('Template not found', 'The file"'.$file.'"not found');
            return false;

        }
        return true;
    }

}
?>