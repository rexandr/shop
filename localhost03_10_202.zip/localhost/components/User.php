<?php
namespace components;

use models\User as UserModels;

class User
{
    public static function auth($id)
    {
        if (setcookie('user', $id, time() + 3600)) {
            return true;
        }

        return false;
    }

    public static function logout()
    {
        setcookie('user', 'null', -1);
        return true;
    }

    public static function id()
    {
        if (isset($_COOKIE['user'])) {
            return $_COOKIE['user'];
        }
        return false;
    }

    public static function info()
    {
        if (self::id()) {
            $model = new UserModels();
            $user = $model->findById(self::id());
            if ($user) {
                return $user;
            }
        }
        return false;
    }

    public static function isAuth()
    {
        if (self::id())
        {
            return true;
        }
        return false;
    }

}