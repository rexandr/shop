<?php
namespace helpers;

class Security
{
    public static function passwordHash($password, $type = PASSWORD_DEFAULT)
    {
        return password_hash($password, $type);
    }

    public static function passwordVerify($password, $hash)
    {
        return password_verify($password, $hash);
    }
}