<?php
namespace helpers;

class UserHelper
{
  public CONST GUEST_ROLE = 1;

  public CONST STATUS_ACTIVE = 1;
  public CONST STATUS_DRAFT = 0;





}
?>