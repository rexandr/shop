<?php
namespace helpers;

class DateHelper
{
    public static function currentTimestamp()
    {
        return time();
    }
}