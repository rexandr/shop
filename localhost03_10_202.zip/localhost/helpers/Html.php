<?php
namespace  helpers;

class Html
{
    public static function filter($var)
    {
        $var = trim($var);
        $var = strip_tags($var);
        return $var;
    }
}