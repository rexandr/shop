<?php
namespace helpers;

use components\Logs;

class FormHelper

{
    public static $className = 'error';

    public static function errors($errors)
    {
        if(is_array($errors))
        {
            $html = '<ul class="'.self::$className.'">';
            foreach ($errors as $error)
            {
                $html .= '<li>'.$error.'</li>';
            }
            $html .= '</ul>';
            return $html;
        }
        else
        {
            Logs::add('Error must be at array', '');
            return false;
        }
    }
}