<?php
namespace assets;

use components\BaseAsset;

class AppAssets extends BaseAsset
{
    private $css = [
      '/css/style.css'
    ];

    private $js = [
        '/js/main.js'
    ];

    public function initCss()
    {
        return $this->renderCss($this->css);
    }


    public function initJs()
    {
        return $this->renderJs($this->js);
    }
}