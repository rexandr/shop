<?php
namespace models;

use components\Db;
use helpers\DateHelper;
use helpers\Html;
use helpers\Security;
use helpers\UserHelper;

class User
{
    public function tableName()
    {
        return 'user';
    }

    public function  findByLogin($login)
    {
        $db=Db::connect();
        $sql = 'SELECT * FROM '.$this->tableName().' WHERE login = :login';
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':login', $login);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function findById($id)
    {
        $db = Db::connect();
        $sql = 'SELECT * FROM '.$this->tableName().' WHERE id = :id';
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':id',$id);
        $stmt->execute();
        return $stmt->fetch();
    }


    public function signup($data)
    {
        $db = Db::connect();
        $sql = 'INSERT INTO '.$this->tableName().' SET
         login = :login,
         password = :password,
         status = :status,
         created_at = :created_at,
         updated_at = :updated_at,
         last_visit = :last_visit';

        $guestRole = UserHelper::GUEST_ROLE;
        $statusActive = UserHelper::STATUS_ACTIVE;
        $currentTimestamp = DateHelper::currentTimestamp();
        $login = Html::filter($data['login']);
        $password = Security::passwordHash($data['password']);

        $stmt = $db->prepare($sql);
        $stmt->bindParam(':login', $login);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':status', $statusActive);
        //$stmt->bindParam(':role', $guestRole);
        $stmt->bindParam(':created_at', $currentTimestamp);
        $stmt->bindParam(':updated_at', $currentTimestamp);
        $stmt->bindParam(':last_visit', $currentTimestamp);
        $stmt->execute();
        return true;
    }



}