<?php

namespace  models;


class SignupForm
{

    private $data;

    public function __construct($data)
    {
        $this->data = $data;
    }

    public function validate()
    {
        $errors = [];
        if (empty($this->data['login'])) {
            $errors[] = 'Login is empty';
        }
        if (empty($this->data['password'])) {
            $errors[] = 'Password is empty';
        }

        $user = new User();
        if ($user->findByLogin($this->data['login']))
        {
            $errors[] = 'login already exist';
        }
        return $errors;
    }



    public function signup()
    {
        if (count($this->validate()) > 0) {
            print_r($this->validate());
            return false;
        }

        $user = new User();
        $user->signup($this->data);
        echo 'user is register';
        return true;
    }
}