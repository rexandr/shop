<?php
namespace models;

use helpers\Security;

class SigninForm
{
    private $data;

    public $errors;

    public function __construct($data)
    {
        $this->data = $data;
    }

    public function validate()
    {
        $errors = [];
        if(empty($this->data['login'])){
            $errors[] = 'Login is empty';
        }
        if(empty($this->data['password'])){
            $errors[] = 'Password is empty';
        }

        $model = new User();
        $user = $model->findByLogin($this->data['login']);
        if(!$user){
            $errors[] = 'Login not found';
        }
        if(isset($user['password'])){
            if(!Security::passwordVerify($this->data['password'], $user['password'])){
                $errors[] = 'Password is wrong';
            }
        }

        $this->errors = $errors;
        return $errors;
    }

    public function signin()
    {
        if(count($this->validate()) > 0)
        {

            return false;
        }

        $model = new User();
        $user = $model->findByLogin($this->data['login']);
        return $user['id'];
    }
}
?>