<?php

class View
{
    public const VIEW_PATH = '/view/';

    public function render($content)
    {

    }
}
?>