<?php
namespace  controllers;
use components\Db;
use components\Controller;
class SiteController extends Controller
{
    public  function ActionIndex()
    {
        Db::connect();
        return $this->render('site/index');
    }

    public  function ActionContact()
    {
       return $this->render('site/contact');
    }
}
