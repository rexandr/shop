<?php

namespace components;

class Autoload
{
    private $folders = [
        'assets',
        'controllers',
        'models'
    ];
    public function run()
    {
        if(is_array($this->folders)){
            foreach ($this->folders as $folder){
                $files = scandir(ROOT.'/'.$folder);
                unset($files[0], $files[1]);
                foreach ($files as $file) {
                    include ROOT . '/' . $folder . '/'.$file;
                    //echo  ROOT . '/' . $folder . '/'.$file;
                }
            }
            return true;
        }
        die('Error! folders not found');
    }
}


?>