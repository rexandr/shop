<?php
namespace components;

class Logs
{
    private static $folder = '/logs/';

    private static  function getFolder()
    {
        if(is_dir(ROOT.self::$folder)){
            return ROOT.self::$folder;
        }
        die('Logs folder not found');
    }
    public static function add($error, $message)
    {
        if(self::getFolder())
        {
            $fileName = self::getFolder().date('d-m-y').'.txt';
            $fp = fopen($fileName, 'a+');
            fwrite($fp, $error.' '.$message.PHP_EOL);
            fclose($fp);
            return true;
        }
    }
}