<?php

namespace components;

use controllers\ErrorController;

class Router
{
    private $routes;
    private $uri;

    public function __construct()
    {
        $this->routes = $this->getRoutes();
        $this->uri = $this->getUrl();
    }


    private function getUrl()
    {
        return $_SERVER['REQUEST_URI'];
    }

    private function getRoutes()
    {
        return include (ROOT . '/config/Routes.php');
    }


    public function run()
    {
        if (isset($this->routes[$this->uri]))
        {
            $params = explode('/', $this->routes[$this->uri]);
            $controller = ucfirst($params[0]).'Controller';
            $action = 'action'.ucfirst($params[1]);
            $controllerName = "controllers\\".$controller;
            $class = new $controllerName;
            $class->$action();
        }
        else {
            $error = new ErrorController();
            $error->actionError('Page not found', 404);
             }
    }
}

?>