<?php
namespace components;

class BaseAsset
{
    public  function renderCss($css)
    {
        if (!is_array($css))
        {
            return false;
        }




        $ver = null;

        if (!empty(CSS_VERSION))
        {
            $ver=CSS_VERSION;
        }





        $html = null;

        foreach($css as $style)
        {
            $html.= '<link rel="stylesheet" src="'.$style;
            if(!empty($ver)){
                $html.='?ver='.$ver;
            }
            $html.='">';
        }
        return $html;
    }
}