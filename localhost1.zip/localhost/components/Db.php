<?php
namespace components;

use PDO;
use PDOException;
class Db
{
    public static function connect()
    {
        try {
            $connect = new PDO('mysql:dbname=' . DB_NAME . ';host=' . DB_SERVER, DB_USER, DB_PASSWORD);
        }
        catch (PDOException $e) {
            Logs::add('Error DataBase connect', $e->getMessage());
            die($e->getMessage());
        }
    }
}