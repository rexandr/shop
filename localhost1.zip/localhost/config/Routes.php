<?php
return[
    '/'=>'site/index',
    '/contact' => 'site/contact'
];

?>