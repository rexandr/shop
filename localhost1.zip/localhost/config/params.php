<?php
//Db params
defined('DB_SERVER') or define('DB_SERVER', 'localhost');
defined('DB_USER') or define('DB_USER', 'root');
defined('DB_PASSWORD') or define('DB_PASSWORD', 'root');
defined('DB_NAME') or define('DB_NAME', 'mvc');
//Assets params
defined('CSS_VERSION') or define('CSS_VERSION', '1.20');

?>
