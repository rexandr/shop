<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);



define ('ROOT', __DIR__);
include ROOT.'/components/Autoload.php';
include ROOT.'/components/Router.php';
include ROOT.'/components/Controller.php';
include ROOT.'/components/Db.php';
include ROOT.'/components/Logs.php';
include ROOT.'/components/BaseAsset.php';


include ROOT.'/config/params.php';

use components\Autoload;
use components\Router;

$autoload = new Autoload();
$autoload->run();


$router = new Router();
$router->run();
?>